import React from 'react';

export function AutoWrapMDX({ children }) {
  if (typeof children !== 'string') return <>{children}</>;

  const words = children.split(/([.,!?;:\\s]+)/); // Split but keep punctuation
  return (
    <>
      {words.map((word, i) => {
        if (word.trim().length === 0 || /[.,!?;:\\s]+/.test(word)) {
          return word;
        }
        return (
          <span
            key={i}
            onClick={() => handleClick(word)}
            style={{ cursor: 'pointer', color: '#0ea5e9' }}
          >
            {word}
          </span>
        );
      })}
    </>
  );
}

async function handleClick(word) {
  const res = await fetch(`/api/lookup?word=${word}`);
  const data = await res.json();

  if (data.translation) {
    alert(`${word} = ${data.translation}\n(${data.type})\n"${data.example_de}" → "${data.example_en}"`);
  } else {
    alert(`No entry found for "${word}"`);
  }
}
