export default function Lesson2() {
  return (
    <main className="min-h-screen p-6 text-gray-800">
      <h1 className="text-2xl font-bold text-teal-700">📘 Lesson 2</h1>
      <p className="text-gray-600">Diese Lektion wird gerade vorbereitet. Schau bald wieder vorbei!</p>
    </main>
  );
}
